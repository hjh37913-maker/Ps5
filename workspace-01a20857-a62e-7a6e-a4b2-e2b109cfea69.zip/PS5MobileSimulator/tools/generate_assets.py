#!/usr/bin/env python3
"""
PS5 Mobile Simulator — original asset pipeline.

Generates all bundled media from the per-game palettes declared in
GameCatalog.kt (single source of truth for visual identity):

  app/src/main/assets/games/<id>/cover.jpg        640x640
  app/src/main/assets/games/<id>/background.jpg   1920x1080
  app/src/main/assets/games/<id>/shot1..3.jpg     1280x720
  app/src/main/assets/games/<id>/launch.mp4       1280x720, 6 s, H.264
  app/src/main/assets/sounds/{nav,select,back,launch}.wav

Everything is ORIGINAL generative art — no copyrighted material is used.
"""

import math
import os
import random
import re
import subprocess
import sys

from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(ROOT, "..", "app", "src", "main", "assets")
CATALOG = os.path.join(ROOT, "..", "app", "src", "main", "java", "com",
                       "kaizer", "ps5simulator", "data", "local", "GameCatalog.kt")
FONT_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONT_REG = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"


# ---------------------------------------------------------------- catalog --

def parse_catalog():
    """Extract (id, title, primary, secondary) from GameCatalog.kt."""
    src = open(CATALOG, encoding="utf-8").read()
    blocks = re.split(r"\n\s*game\(\n", src)[1:]
    games = []
    for block in blocks:
        gid = re.search(r'id = "([^"]+)"', block).group(1)
        title = re.search(r'title = "([^"]+)"', block).group(1)
        p = re.search(r"accentPrimary = 0xFF([0-9A-Fa-f]{6})", block).group(1)
        s = re.search(r"accentSecondary = 0xFF([0-9A-Fa-f]{6})", block).group(1)
        games.append({
            "id": gid,
            "title": title.replace("\\u0027", "'"),
            "primary": tuple(int(p[i:i + 2], 16) for i in (0, 2, 4)),
            "secondary": tuple(int(s[i:i + 2], 16) for i in (0, 2, 4)),
        })
    return games


# ------------------------------------------------------------ image utils --

def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def radial_glow(size, center, radius, color, peak_alpha=160):
    """Soft radial glow rendered on a small buffer and upscaled."""
    w, h = size
    small_w, small_h = max(1, w // 8), max(1, h // 8)
    buf = Image.new("L", (small_w, small_h), 0)
    d = ImageDraw.Draw(buf)
    cx, cy = center[0] // 8, center[1] // 8
    r = max(1, radius // 8)
    steps = 24
    for i in range(steps, 0, -1):
        rr = r * i / steps
        alpha = int(peak_alpha * (1 - i / steps) ** 1.6)
        d.ellipse([cx - rr, cy - rr, cx + rr, cy + rr], fill=alpha)
    buf = buf.resize((w, h), Image.BICUBIC).filter(ImageFilter.GaussianBlur(radius=w // 200))
    layer = Image.new("RGB", size, color)
    return buf, layer


def diagonal_gradient(size, c_top, c_bottom):
    w, h = size
    small = Image.new("RGB", (2, 2))
    small.putpixel((0, 0), c_top)
    small.putpixel((1, 0), lerp(c_top, c_bottom, 0.35))
    small.putpixel((0, 1), lerp(c_top, c_bottom, 0.65))
    small.putpixel((1, 1), c_bottom)
    return small.resize((w, h), Image.BICUBIC)


def vignette(img, strength=140):
    w, h = img.size
    small = Image.new("L", (w // 16, h // 16), 0)
    d = ImageDraw.Draw(small)
    d.ellipse([-w // 24, -h // 16, w // 16 + w // 16, h // 16 + h // 8], fill=255)
    mask = small.resize((w, h), Image.BICUBIC).filter(ImageFilter.GaussianBlur(w // 60))
    black = Image.new("RGB", (w, h), (0, 0, 0))
    return Image.composite(img, Image.blend(img, black, strength / 255.0), mask)


def add_stars(img, rng, count, bright=200):
    d = ImageDraw.Draw(img)
    w, h = img.size
    for _ in range(count):
        x, y = rng.randint(0, w - 1), rng.randint(0, h - 1)
        b = rng.randint(bright // 3, bright)
        r = rng.choice([1, 1, 1, 2])
        d.ellipse([x - r, y - r, x + r, y + r], fill=(b, b, min(255, b + 20)))
    return img


def ridge(size, horizon, rough, color, rng):
    """One silhouette ridge line for the screenshot 'scenes'."""
    w, h = size
    pts = [(0, h)]
    y = horizon
    for x in range(0, w + 1, w // 24):
        y += rng.randint(-rough, rough)
        y = max(h // 4, min(h - 10, y))
        pts.append((x, y))
    pts.append((w, h))
    layer = Image.new("RGB", size, color)
    mask = Image.new("L", size, 0)
    ImageDraw.Draw(mask).polygon(pts, fill=255)
    return layer, mask


def title_block(img, title, sub, y_frac=0.8, font_size=44):
    w, h = img.size
    d = ImageDraw.Draw(img)
    font = ImageFont.truetype(FONT_BOLD, font_size)
    small = ImageFont.truetype(FONT_REG, max(14, font_size // 3))
    # wrap title
    words, lines, cur = title.split(), [], ""
    for word in words:
        probe = (cur + " " + word).strip()
        if d.textlength(probe, font=font) > w * 0.86 and cur:
            lines.append(cur)
            cur = word
        else:
            cur = probe
    lines.append(cur)
    y = int(h * y_frac)
    for line in lines:
        tw = d.textlength(line, font=font)
        d.text(((w - tw) / 2, y), line, font=font, fill=(245, 247, 252))
        y += int(font_size * 1.15)
    if sub:
        sw = d.textlength(sub, font=small)
        d.text(((w - sw) / 2, y + 4), sub, font=small, fill=(200, 205, 215))
    return img


def mark_concept(img):
    """Honesty tag: every generated image carries a small 'concept art' mark."""
    d = ImageDraw.Draw(img)
    font = ImageFont.truetype(FONT_REG, 13)
    text = "SIMULATOR CONCEPT ART"
    tw = d.textlength(text, font=font)
    d.text((img.size[0] - tw - 14, img.size[1] - 24), text, font=font,
           fill=(255, 255, 255))
    return img


# --------------------------------------------------------------- renderers --

def render_cover(game, path):
    rng = random.Random("cover/" + game["id"])
    w = h = 640
    img = diagonal_gradient((w, h), game["primary"], game["secondary"])

    # translucent geometric motifs
    for _ in range(4):
        mask, layer = radial_glow(
            (w, h),
            (rng.randint(0, w), rng.randint(0, h)),
            rng.randint(120, 260),
            lerp(game["primary"], (255, 255, 255), 0.25),
            peak_alpha=rng.randint(40, 90),
        )
        img = Image.composite(layer, img, mask)

    # big monogram
    d = ImageDraw.Draw(img)
    mono = game["title"][0].upper()
    font = ImageFont.truetype(FONT_BOLD, 340)
    tw = d.textlength(mono, font=font)
    bbox = font.getbbox(mono)
    tx, ty = (w - tw) / 2, (h - (bbox[3] - bbox[1])) / 2 - bbox[1] - 40
    d.text((tx + 6, ty + 6), mono, font=font, fill=(0, 0, 0))
    d.text((tx, ty), mono, font=font, fill=(250, 250, 255))

    img = title_block(img, game["title"], "PS5 MOBILE SIMULATOR", y_frac=0.84, font_size=34)
    img = vignette(img, 90)
    img = mark_concept(img)
    img.convert("RGB").save(path, quality=88, optimize=True)


def render_background(game, path):
    rng = random.Random("bg/" + game["id"])
    w, h = 1920, 1080
    img = diagonal_gradient((w, h),
                            lerp(game["secondary"], (0, 0, 0), 0.35),
                            lerp(game["primary"], (0, 0, 0), 0.55))
    for _ in range(5):
        mask, layer = radial_glow(
            (w, h),
            (rng.randint(0, w), rng.randint(0, h)),
            rng.randint(300, 640),
            lerp(game["primary"], (255, 255, 255), rng.uniform(0.0, 0.3)),
            peak_alpha=rng.randint(50, 110),
        )
        img = Image.composite(layer, img, mask)
    img = add_stars(img, rng, 260)
    # aurora band
    band = Image.new("L", (w, h), 0)
    bd = ImageDraw.Draw(band)
    base_y = rng.randint(h // 4, h // 2)
    pts_top, pts_bot = [], []
    for x in range(0, w + 1, 24):
        y = base_y + int(80 * math.sin(x / 340.0 + rng.random()))
        pts_top.append((x, y))
        pts_bot.append((x, y + rng.randint(60, 120)))
    bd.polygon(pts_top + pts_bot[::-1], fill=70)
    band = band.filter(ImageFilter.GaussianBlur(40))
    img = Image.composite(lerp(game["primary"], (255, 255, 255), 0.4) and
                          Image.new("RGB", (w, h), lerp(game["primary"], (255, 255, 255), 0.35)),
                          img, band)
    img = vignette(img, 150)
    img = mark_concept(img)
    img.convert("RGB").save(path, quality=86, optimize=True)


def render_shot(game, path, idx):
    rng = random.Random(f"shot{idx}/" + game["id"])
    w, h = 1280, 720
    sky_top = lerp(game["secondary"], (10, 10, 20), 0.25)
    sky_bot = lerp(game["primary"], (20, 20, 30), 0.15)
    img = diagonal_gradient((w, h), sky_top, sky_bot)
    img = add_stars(img, rng, 140)

    horizon = rng.randint(h // 2, int(h * 0.66))
    for i, (shade, rough) in enumerate([(0.05, 26), (0.12, 34), (0.2, 20)]):
        layer, mask = ridge((w, h), horizon + i * rng.randint(30, 70), rough,
                            lerp(game["secondary"], (0, 0, 0), 0.55 + shade), rng)
        img = Image.composite(layer, img, mask)

    # glow orb (sun/moon)
    mask, layer = radial_glow((w, h), (rng.randint(w // 4, 3 * w // 4),
                                       rng.randint(h // 6, h // 3)),
                              rng.randint(90, 160),
                              lerp(game["primary"], (255, 255, 255), 0.5),
                              peak_alpha=200)
    img = Image.composite(layer, img, mask)

    d = ImageDraw.Draw(img)
    font = ImageFont.truetype(FONT_BOLD, 26)
    d.text((28, 22), game["title"], font=font, fill=(240, 243, 250))
    img = vignette(img, 110)
    img = mark_concept(img)
    img.convert("RGB").save(path, quality=85, optimize=True)


def hex6(rgb):
    return "0x%02X%02X%02X" % rgb


def esc(text):
    return (text.replace("\\", "\\\\").replace(":", "\\:")
                .replace("'", "\u2019").replace("%", "\\%"))


def render_video(game, path):
    """Main intro: 1080p, 10 s, animated gradient scene with title reveal."""
    p, s = game["primary"], game["secondary"]
    c2 = lerp(p, (255, 255, 255), 0.18)
    c3 = lerp(s, (0, 0, 0), 0.4)
    lavfi = (f"gradients=s=1920x1080:c0={hex6(p)}:c1={hex6(s)}:c2={hex6(c2)}:c3={hex6(c3)}"
             f":speed=0.03:rate=24:duration=15")
    vf = (
        "noise=alls=7:allf=t,"
        f"drawtext=fontfile={FONT_BOLD}:text='{esc(game['title'])}':"
        "fontcolor=white:fontsize=96:x=(w-text_w)/2:y=(h-text_h)/2-30:"
        "alpha='if(lt(t,1.2),0,if(lt(t,2.4),(t-1.2)/1.2,1))',"
        f"drawtext=fontfile={FONT_REG}:text='PS5 Mobile Simulator - demo intro':"
        "fontcolor=0xC8CDD8:fontsize=36:x=(w-text_w)/2:y=(h-text_h)/2+70:"
        "alpha='if(lt(t,1.8),0,if(lt(t,3.0),(t-1.8)/1.2,1))',"
        "fade=t=in:st=0:d=0.9,fade=t=out:st=13.6:d=1.4,vignette=PI/4"
    )
    cmd = [
        "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
        "-f", "lavfi", "-i", lavfi,
        "-vf", vf,
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "22",
        "-pix_fmt", "yuv420p", "-movflags", "+faststart",
        "-t", "15", path,
    ]
    subprocess.run(cmd, check=True)


def render_loading_video(game, path):
    """Short loading loop: 1080p, 4 s, pulsing gradient + 'Loading...'."""
    p, s = game["primary"], game["secondary"]
    c2 = lerp(p, (0, 0, 0), 0.5)
    c3 = lerp(s, (255, 255, 255), 0.10)
    lavfi = (f"gradients=s=1920x1080:c0={hex6(s)}:c1={hex6(c2)}:c2={hex6(p)}:c3={hex6(c3)}"
             f":speed=0.12:rate=24:duration=4")
    vf = (
        "noise=alls=7:allf=t,"
        f"drawtext=fontfile={FONT_BOLD}:text='{esc(game['title'])}':"
        "fontcolor=white:fontsize=64:x=(w-text_w)/2:y=h*0.72:"
        "alpha='0.55+0.45*sin(2*PI*t/2)',"
        f"drawtext=fontfile={FONT_REG}:text='Loading...':"
        "fontcolor=0xB8BDC8:fontsize=34:x=(w-text_w)/2:y=h*0.72+90,"
        "vignette=PI/4"
    )
    cmd = [
        "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
        "-f", "lavfi", "-i", lavfi,
        "-vf", vf,
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "22",
        "-pix_fmt", "yuv420p", "-movflags", "+faststart",
        "-t", "4", path,
    ]
    subprocess.run(cmd, check=True)


def render_sounds(sounds_dir):
    os.makedirs(sounds_dir, exist_ok=True)

    def gen(name, src, af, duration):
        subprocess.run([
            "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
            "-f", "lavfi", "-i", src, "-af", af, "-t", str(duration),
            os.path.join(sounds_dir, name),
        ], check=True)

    gen("nav.wav", "sine=frequency=1150", "afade=t=out:st=0.03:d=0.03,volume=0.45", 0.06)
    gen("select.wav", "sine=frequency=1568", "afade=t=in:d=0.01,afade=t=out:st=0.06:d=0.05,volume=0.5", 0.11)
    gen("back.wav", "sine=frequency=784", "afade=t=out:st=0.05:d=0.05,volume=0.5", 0.1)
    gen("launch.wav",
        "aevalsrc=sin(2*PI*(380+900*t)*t)*exp(-t*2)",
        "afade=t=in:d=0.05,volume=0.6", 0.7)


# ------------------------------------------------------------------- main --

def main():
    games = parse_catalog()
    print(f"[assets] {len(games)} games parsed from GameCatalog.kt")
    only = sys.argv[1] if len(sys.argv) > 1 else None
    skip_video = "--no-video" in sys.argv

    render_sounds(os.path.join(ASSETS, "sounds"))
    print("[assets] sounds done")

    for g in games:
        if only and only not in ("videos", "images", "intros") and g["id"] != only:
            continue
        gdir = os.path.join(ASSETS, "games", g["id"])
        os.makedirs(gdir, exist_ok=True)
        if only != "videos":
            render_cover(g, os.path.join(gdir, "cover.jpg"))
            render_background(g, os.path.join(gdir, "background.jpg"))
            for i in (1, 2, 3):
                render_shot(g, os.path.join(gdir, f"shot{i}.jpg"), i)
            print(f"[assets] images done: {g['id']}")
        if not skip_video and only != "images":
            render_video(g, os.path.join(gdir, "launch.mp4"))
            if only != "intros":
                render_loading_video(g, os.path.join(gdir, "loading.mp4"))
            print(f"[assets] videos done: {g['id']}")

    print("[assets] ALL DONE")


if __name__ == "__main__":
    main()
