# PS5 Mobile Simulator

Native Android simulator of the PlayStation 5 user experience — home screen,
game library, game details, real video launch sequences, demo store, Game Base,
profile, demo trophies, Control Center, notifications, media center and a full
settings system.

> **Legal notice.** This is an independent fan-made *interface simulator*.
> It is **not affiliated with, endorsed by, or connected to Sony Interactive
> Entertainment**. It cannot run real PS5 games and never connects to PSN.
> All bundled artwork, screenshots and videos are **original generative media**
> produced by `tools/generate_assets.py` — no copyrighted Sony or publisher
> assets are included. Every generated image carries a small
> "SIMULATOR CONCEPT ART" mark.

## Tech stack

| Area | Technology |
|---|---|
| Language | Kotlin 2.0.21 |
| UI | Jetpack Compose (BOM 2024.12.01), Material 3 (base only) |
| Navigation | Navigation Compose 2.8.4 |
| Video | AndroidX Media3 ExoPlayer 1.5.0 |
| Persistence | Room 2.6.1 (6 entities, migration 1→2) + DataStore Preferences |
| Images | Coil 2.7.0 (+ custom blur transformation) |
| Async | Kotlin Coroutines / Flow |
| DI | Hand-rolled `AppContainer` service locator |
| Min SDK / Target | 26 / 35 |
| Build | Gradle 8.10.2, AGP 8.7.2, KSP |

## Architecture

Single-app-module MVVM with Clean-style layering:

```
com.kaizer.ps5simulator
├── App.kt                  # Application + AppContainer (DI) + seeding
├── MainActivity.kt         # edge-to-edge host, orientation/fullscreen, overlays
├── core/
│   ├── common/             # GameLaunchController (state machine), ToastBus, Formatters
│   ├── database/           # Room: entities, DAOs, AppDatabase (+ MIGRATION_1_2)
│   ├── datastore/          # SettingsManager (DataStore, injectable for tests)
│   ├── design/             # Theme, Localization (EN/RU/UK), Components, Cards
│   ├── media/              # PS5VideoPlayer (ExoPlayer), SoundManager, Blur, AssetProbe
│   └── navigation/         # Routes + AppNavHost
├── data/
│   ├── local/              # GameCatalog (30 real games), TrophyCatalog, GameBaseData
│   ├── model/              # Game, GameLaunchConfig, Trophy, FriendProfile, ...
│   └── repository/         # Game/Favorites/History/Profile/Trophy/Notification/Settings
└── feature/
    ├── home/               # PS5 home: dynamic bg, game row, media tab
    ├── library/            # grid, search, sorting, favorites-first
    ├── store/              # demo store (purchases disabled, honest labels)
    ├── gamedetails/        # details, gallery + fullscreen viewer, history
    ├── gamelaunch/         # GameLaunchActivity: intro video → loading → auto return
    ├── gamebase/           # demo friends/groups/messages/invites
    ├── profile/            # profile edit, stats, collection
    ├── trophies/           # demo trophy cabinet (NOT real PSN)
    ├── notifications/      # local notification feed
    ├── controlcenter/      # bottom overlay above any screen
    ├── settings/           # display/visual/sound/library/storage/general
    └── mediacenter/        # screenshot gallery + local video playback
```

## Game launch sequence

`Play` → press animation → `GameLaunchActivity` (landscape, fullscreen) →
per-game 1080p intro video (ExoPlayer, skippable) → per-game loading video →
automatic return home. History, demo trophies and notifications are recorded
via `LaunchTracker`. If a video asset is missing/corrupt, a branded fallback
screen is shown — never another game's media.

## Media assets

`app/src/main/assets/games/<id>/` per game: `cover.jpg` (640²),
`background.jpg` (1920×1080), `shot1..3.jpg` (1280×720),
`launch.mp4` (10 s), `loading.mp4` (4 s). Sounds in `assets/sounds/`.

To regenerate: `python3 tools/generate_assets.py` (needs Pillow + ffmpeg).
To use your own legally obtained media: overwrite files in the same folders —
the app picks them up transparently (Coil loads `file:///android_asset/...`,
ExoPlayer loads `asset:///...`).

## Build

```bash
# needs JDK 17+ (built with JDK 21) and ANDROID_HOME
./gradlew :app:assembleDebug          # debug APK
./gradlew :app:assembleRelease        # signed release (needs keystore.properties)
./gradlew :app:testDebugUnitTest      # JVM unit tests (27)
./gradlew :app:connectedDebugAndroidTest  # instrumentation tests (device/emulator)
```

Release signing is configured via a git-ignored `keystore.properties`:

```properties
storeFile=ps5sim.keystore
storePassword=...
keyAlias=ps5sim
keyPassword=...
```

## Offline

All sections work offline. `INTERNET` permission exists only so that
user-supplied remote Coil/ExoPlayer sources could work; nothing is fetched
by default and no personal data leaves the device.
