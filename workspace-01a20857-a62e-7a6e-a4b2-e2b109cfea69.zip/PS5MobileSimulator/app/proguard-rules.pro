# Project-wide Gradle settings - default ProGuard rules for the release build.

# Kotlin / Coroutines
-keepclassmembers class kotlinx.coroutines.** { *; }
-dontwarn kotlinx.coroutines.**

# Room
-keep class * extends androidx.room.RoomDatabase { *; }
-dontwarn androidx.room.paging.**

# Media3
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Coil
-keep class coil.** { *; }

# Keep data models used via reflection/serialization-free DAO mapping
-keep class com.kaizer.ps5simulator.data.model.** { *; }
-keep class com.kaizer.ps5simulator.core.database.** { *; }

# Compose
-keep class androidx.compose.** { *; }
-dontwarn androidx.compose.**
-dontnote androidx.compose.**

# General
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod
-dontwarn org.jetbrains.annotations.**
